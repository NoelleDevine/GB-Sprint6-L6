import sys
import cv2
import os


# Get user supplied values
scriptDirectory = os.path.dirname(__file__)
imagePath = os.path.join(scriptDirectory, "abba.png")

cascPath = os.path.join(scriptDirectory, "haarcascade_frontalface_default.xml")

# Create the haar cascade
faceCascade = cv2.CascadeClassifier(cascPath)

# Read the image
image = cv2.imread(imagePath)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Detect faces in the image
faces = faceCascade.detectMultiScale( 
    gray,
    scaleFactor=1.1,
    minNeighbors=5,
    minSize=(30, 30),
    flags=cv2.CASCADE_SCALE_IMAGE
)

print("Found {0} faces!".format(len(faces)))

# Draw a rectangle around the faces
for (x, y, w, h) in faces:
    cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)

# Save the image in local project folder
outputPath = os.path.join(scriptDirectory, "abba_face_detected.jpg")
cv2.imwrite(outputPath, image)



"""
CHALLENGES:
- Can you make this live with your webcam?
"""